import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Switch
} from "react-router-dom";
import { Auto } from "./auto/Auto";
import { Home } from "./home/Home";
import React from 'react';

function App() {
  return (
    <Router>
      <React.StrictMode>
    <div className="App">
    <nav>
        <ul>
            {/*<li class="brand"><i mg src="logomusic3.png" alt="1"  ></li>*/}
            <img class="" src="logomusic3.png" alt="1" height="50px" width="110px" />
            <Link to="/">Home</Link>
            <a href="about.html">About</a>
            <a href="">Contact</a>
            <Link to="/auto">My Playlist</Link>
        </ul>
    </nav> 

    <Switch>
            <Route path="/" exact>
              <Home />
            </Route>
            <Route path="/auto">
              <Auto />
            </Route>
    </Switch>
    
    </div>
    
    </React.StrictMode>
  </Router>
  );
}

export default App;
