import './auto.css'
import { useEffect, useState, useRef } from 'react'

export const Auto = () => {

    const songs = [
        {k: 0, songName: "Born to Shine - Diljit Dosanjh", filePath:"song1.mp3",coverPath:"cover10.jpg"},
        {k: 1, songName: "Satranga - Arijit singh", filePath:"song2.mp3",coverPath:"cover3.jpg"},
        {k: 2, songName: "Udaarian - Satinder Sartaaj", filePath:"song3.mp3",coverPath:"cover2.webp"},
        {k: 3, songName: "Tum se hi - Mohit Chauhan", filePath:"song4.mp3",coverPath:"cover4.jpg"},
        {k: 4, songName: "Shape of you - Ed Sheeran", filePath:"song5.mp3",coverPath:"cover5.png"},
        {k: 5, songName: "Closer -  Chainsmokers & Andrew Taggart", filePath:"song6.mp3",coverPath:"cover5.jpg"},
    ];

    console.log(songs.length)

    const [masterSong, setMasterSong] = useState(0);

    const [playing, setPlaying] = useState(false);
    const [progressBarValue, setProgressBarValue] = useState(0);

    const audio = useRef(new Audio(songs[0].filePath));
    const audioElement = audio.current;

    const playSongOnClick = (song) => {
        if(masterSong === song.k && playing){
            setPlaying(false)
        } else {
            setMasterSong(song.k)
            setPlaying(true)
        }
    }

    const songContainer =  (
        <div className="songItemContainer">
            {songs.map(song => (
                <div className="songItem">
                    <img src={song.coverPath} alt="1"/>
                    <span className="songName">{song.songName}</span>
                    <span className="songlistplay"><span className="timestamp">05:34<i id="0" className={`songItemPlay fa-regular ${masterSong === song.k && playing ? 'fa-circle-pause' : 'fa-circle-play'}`} onClick={() => playSongOnClick(song)}></i></span></span>
                </div>
                )
            )}
            </div>
    )

    useEffect(() => {
        console.log("new Master song", masterSong)
        audioElement.src = songs[masterSong].filePath;       
        audioElement.currentTime = 0;
        setProgressBarValue(0);
        if(playing) {
            audioElement.play()
        } else {
            audioElement.pause()
        }
        
        audioElement.addEventListener('timeupdate', ()=>{
            console.log('timeupdate');
        //Update Seekbar
            let progress = parseInt((audioElement.currentTime/audioElement.duration)*100);
            console.log(progress, progressBarValue);
            if(progress && progressBarValue !== progress){
                console.log("updating progress bar value")
                setProgressBarValue(progress);
            }
        })

        return () => audioElement.pause()
    }, [masterSong, playing])


    console.log("rendered")
    return (    
        <div>
            <div className="container">
                <div className="songlist">
                    <h1>My Playlist</h1>
                {songContainer}
                </div>
            <div className="songBanner"></div>

            </div>
            <div className="bottom">
                <input type="range" name="range" id="myProgressBar" value={progressBarValue} onChange={(e) => {
                    setProgressBarValue(e.target.value)
                    audioElement.currentTime = e.target.value*audioElement.duration/100;
                }}/>
                <div className="icons">
                    <i className="fa-solid  fa-backward-step" id="previous" onClick={() => {
                        setMasterSong(masterSong === 0 ? songs.length - 1 : masterSong-1)
                    }} ></i>
                    <i className={`fa-regular ${playing ? 'fa-circle-pause' : 'fa-circle-play'}`} id="Play" onClick={() => setPlaying(!playing)}></i>
                    <i className="fa-solid  fa-forward-step" id="next" onClick={() => {
                        setMasterSong((masterSong+1)%songs.length)
                    }}></i>
                    
                </div>
                <div className="songinfo">
                <span id="masterSongName">{songs[masterSong].songName}</span> 
                </div>

            </div>
        </div>
    )
}
