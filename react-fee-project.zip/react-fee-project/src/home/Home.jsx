import React from "react"

export function Home () {

    return(
        <div class="main">
            <div class="heading">
                <h1>Singers</h1>
            </div>
            <div class="Browse-Playlists">
                <a href="https://open.spotify.com/artist/4YRxDV8wJFPHPTeXepOstw" class="playlist">
                    <img src="Arijit-Singh.png" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>Arijit Singh</h3>
                </a>
                <a href="https://open.spotify.com/artist/6LEG9Ld1aLImEFEVHdWNSB?si=84c14df8c99e4c3f" class="playlist">
                    <img src="AP.png" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>A.P. Dhillon</h3>
                </a>
                <a href="https://open.spotify.com/artist/3TVXtAsR1Inumwj472S9r4?si=64c0e7204cc34712" class="playlist">
                    <img src="Drake.png" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>Drake</h3>
                </a>
                <a href="https://open.spotify.com/artist/5f4QpKfy7ptCHwTqspnSJI?si=a50ba5d3334c4a1a" class="playlist">
                    <img src="Neha.png" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>Neha Kakkar</h3>
                </a>
                <a href="https://open.spotify.com/artist/5WUlDfRSoLAfcVSX1WnrxN?si=e0f9d4bb0c884c06" class="playlist">
                    <img src="Sia.png" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>Sia</h3>
                </a>
                <a href="https://open.spotify.com/artist/4PULA4EFzYTrxYvOVlwpiQ?si=e2b6e6d09fa94f0f" class="playlist">
                    <img src="Sidhu.jpg" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>Sidhu Moose Wala</h3>
                </a>
                <a href="https://open.spotify.com/artist/66CXWjxzNUsdJxJ2JdwvnR?si=f47e77747b8d4ad8" class="playlist">
                    <img src="Ariana.jpg" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>Ariane grand</h3>
                </a>
                <a href="https://open.spotify.com/artist/1tqysapcCh1lWEAc9dIFpa?si=c04c58d6bddc41cd" class="playlist">
                    <img src="Zubin.jpg" alt="Playlist Cover"/>
                    <div class="play-button">
                        <svg viewBox="0 0 24 24" fill="white" width="100%" height="100%">
                            <path d="M8 5v14l11-7z"></path>
                        </svg>
                    </div>
                    <h3>Zubin Nautiyal</h3>
                </a>
            </div>
            <div class="heading">
                <h1>Browse all</h1>
            </div>
            <div class="Browsing-Playlists">
                <a href="https://open.spotify.com/genre/0JQ5DArNBzkmxXHCqFLx2J" class="browse">
                    <img src="Podcasts.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/concerts" class="browse">
                    <img src="Live.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAt0tbjZptfcdMSKl3" class="browse">
                    <img src="Made.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFz6FAsUtgAab" class="browse">
                    <img src="New.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFAUsdyVjCQuL" class="browse">
                    <img src="Love.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFOTGtSOysEXE" class="browse">
                    <img src="Devotional.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFCuoRTxhYWow" class="browse">
                    <img src="Sleep.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFAEu5QlAkwvV" class="browse">
                    <img src="Indian Classical.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFRieVZLLoo9m" class="browse">
                    <img src="Instrumental.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFHCxg5H5PtqW" class="browse">
                    <img src="Hindi.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFKSopHMaeIeI" class="browse">
                    <img src="Punjabi.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAB3zgCauRwnvdEQjJ" class="browse">
                    <img src="Charts.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFQ3ZuyILnKhg" class="browse">
                    <img src="Video.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFQRiNGmKYj3B" class="browse">
                    <img src="Busi-Tech.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFEC4WFtoNRpw" class="browse">
                    <img src="Pop.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFQIL0AXnG5AK" class="browse">
                    <img src="Trending.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFQ00XGBls6ym" class="browse">
                    <img src="Hip-Hop.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFIVNxQgRNSg0" class="browse">
                    <img src="Decades.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFziKOShCi009" class="browse">
                    <img src="Anime.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFJw7QLnM27p6" class="browse">
                    <img src="Student.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFAXlCG6QvYQ4" class="browse">
                    <img src="Workout.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFDBgllo2cUIN" class="browse">
                    <img src="Singles.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFx0uLQR2okcc" class="browse">
                    <img src="Home.png" alt="Playlist Cover"/>
                </a>
                <a href="https://open.spotify.com/genre/0JQ5DAqbMKFAJ5xb0fwo9m" class="browse">
                    <img src="Jazz.png" alt="Playlist Cover"/>
                </a>
            </div>
            <div class="main-footer">
                <footer>
                    <table class="footer">
                        <thead>
                            <tr styles={{color:"#ffffff"}} >
                                <th>Company</th>
                                <th>Communities</th>
                                <th>Useful links</th>
                                <th id="c4">
                                    <a href="https://www.instagram.com/spotify" class="social-icons" target="_blank"><img src="Facebook.jpg" alt="relateable image" width="46px" height="46px"/></a>
                                    <a href="https://twitter.com/spotify" class="social-icons" target="_blank"><img src="Instagram.jpg" alt="relateable image" width="46px" height="46px"/></a>
                                    <a href="https://www.facebook.com/SpotifyIndia/?brand_redir=6243987495" class="social-icons" target="_blank"><img src="Twitter.jpg" alt="relateable image" width="46px" height="46px"/></a>
                                </th>
                                </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <a href="https://www.spotify.com/in-en/about-us/contact/" class="nav_a">About Us</a>
                                    <br/>
                                    <a href="https://www.lifeatspotify.com/" class="nav_a">Jobs</a>
                                    <br/>
                                    <a href="https://newsroom.spotify.com/" class="nav_a">For the record</a>
                                    <br/>
                                </td>
                                <td>
                                    <a href="https://artists.spotify.com/home" class="nav_a">For artists</a>
                                    <br/>
                                    <a href="https://developer.spotify.com/" class="nav_a">Developers</a>
                                    <br/>
                                    <a href="https://ads.spotify.com/en-IN/" class="nav_a">Advertising</a>
                                    <br/>
                                    <a href="https://investors.spotify.com/home/default.aspx" class="nav_a">Investors</a>
                                    <br/>
                                    <a href="https://spotifyforvendors.com/" class="nav_a">Vendors</a>
                                    <br/>
                                </td>
                                <td>
                                    <a href="https://support.spotify.com/in-en/" class="nav_a">Support</a>
                                    <br/>
                                    <a href="https://www.spotify.com/in-en/free/" class="nav_a">Free Mobile App</a>
                                    <br/>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="final-footer">
                        <h4>© 2024 Spotify AB</h4>
                    </div>
                </footer> 
            </div>
        
        </div>
    )
}